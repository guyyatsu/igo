# igo
A machine learning training gym for analysis for the game of Go.
